# CS544 HW 5
# Name: Yuxiao Wu
# Date: 11/20/2021

# Part 1 Central Limit Theorem
library(prob)
library(sampling)
options(digits=4)
boston <- read.csv(
  "https://people.bu.edu/kalathur/datasets/bostonCityEarnings.csv",
  colClasses = c("character", "character", "character", "integer", "character"))

# a)
earnings <- boston$Earnings
hist(earnings, xlim = c(40000, 400000), breaks = 18)
xbar <- mean(earnings)
xbar
stdx <- sd(earnings)
stdx
cat("The earnings are not in normal distrubution, most
    people have income between 50000 to 150000, fewer 
    people have income greater than 150000")

# b)
set.seed(7174)
samples <- 5000
sample.size <- 10

xbar <- numeric(samples)

for (i in 1: samples) {
  s <- srswor(sample.size, length(earnings))
  sample.1 <- earnings[s != 0]
  xbar[i] <- mean(sample.1)
}

hist(xbar, prob = TRUE, xlim = c(40000, 180000),
     ylim = c(0, 0.00005), breaks = 15, 
     main = 'Sample size = 10'
     )

mean(xbar)
sd(xbar)

# c)
set.seed(7174)
samples <- 5000
sample.size <- 40

xbar <- numeric(samples)

for (i in 1: samples) {
  s <- srswor(sample.size, length(earnings))
  sample.1 <- earnings[s != 0]
  xbar[i] <- mean(sample.1)
}

hist(xbar, prob = TRUE, xlim = c(40000, 180000),
     ylim = c(0, 0.00005), breaks = 15, 
     main = 'Sample size = 40'
)

mean(xbar)
sd(xbar)

# d)
cat("Means for three distrubutions are about the same, 
    while the std is smaller for larger sample.size")

# Part 2 Central Limit Theorem - Negative Binomial distribution 
# a)
set.seed(7174)
size = 3
prob = 0.5
samples <- 5000
x <- rnbinom(samples, size, prob)
barplot(prop.table(table(x)), xlab = 'x', ylab = 'Proportion',
        ylim = c(0,0.2))

# b)
samples <- 1000
par(mfrow = c(2,2))
xbar <- numeric(samples)
for (samples.size in c(10, 20, 30, 40)) {
  for (i in 1:samples) {
    xbar[i] <- mean(rnbinom(samples.size, size = 3, prob = 0.5))
  }
  
  hist(xbar, prob = TRUE, xlim = c(1,6), ylim = c(0,1),
       breaks = 15,
       main = paste("Sample Size =", samples.size))
  
  cat("Sample Size = ", samples.size, " Mean = ", mean(xbar),
      " SD = ", sd(xbar), "\n")
}
par(mfrow = c(1,1))

# c) 
cat("original data sample mean =", mean(x), "SD = ", sd(x))
cat("Means for the distrubutions are about the same, 
    while the std is smaller for larger sample.size")

# Part 3 Sampling

set.seed(7174)
dep <- unique(boston$Department)
num_employee <- numeric(length(dep))
for (i in 1:length(dep)){
  num_employee[i] <- sum(boston$Department == dep[i])
}
names(num_employee) <- dep
num_employee <- sort(num_employee, decreasing = TRUE)
top_5_dep <- names(num_employee[1:5])
boston1 <- boston[boston$Department %in% top_5_dep,]

# a)
s <- srswor(50, nrow(boston1))

sample.a <- boston1[s != 0, ]

table(sample.a$Department)
prop.table(table(sample.a$Department))

# b)
N <- nrow(boston1)
n <- 50

k <- ceiling(N / n)

r <- sample(k, 1)

s <- seq(r, by = k, length = n)

sample.b <- boston1[s, ]

table(sample.b$Department)

prop.table(table(sample.b$Department))

# c)
set.seed(7174)
pik <- inclusionprobabilities(
  boston1$Earnings, 50)

s <- UPsystematic(pik)

sample.c <- boston1[s != 0, ]

table(sample.b$Department)

prop.table(table(sample.b$Department))

# d)
set.seed(7174)
boston1 <- boston1[order(boston1$Department),]

freq <- table(boston1$Department)

st.sizes <- round(50 * freq / sum(freq))
st.sizes[2] = 24

st.d <- sampling::strata(boston1, stratanames = c("Department"),
                         size = st.sizes, method = "srswor",
                         description = TRUE)

sample.d <- getdata(boston1, st.d)
table(sample.d$Department)
prop.table(table(sample.d$Department))

# e)
# oringial data
mean(boston1$Earnings)

# simple random
mean(sample.a$Earnings)

# systematic
mean(sample.b$Earnings)

# unequal probabilities
mean(sample.c$Earnings)

# stratified
mean(sample.d$Earnings)

