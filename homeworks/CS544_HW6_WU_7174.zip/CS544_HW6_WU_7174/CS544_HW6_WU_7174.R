# CS544 Homework 6
# Yuxiao Wu
# 12/2/2021
library(stringr)
library(tidyverse)
library(plotly)

# Part 1) Strings
file <- "http://people.bu.edu/kalathur/datasets/lincoln.txt"
words <- scan(file, what=character())

# a)
words[str_detect(words, "[,./;)`~'(*&^$#@+_!-=)><?:]")]

# b)
new_words <- str_replace_all(words,"[,./;)`~'(*&^$#@+_!-=)><?:]", ' ')
new_words <- str_replace_all(new_words, ' ', '')
new_words <- new_words[new_words != '']
new_words <- tolower(new_words)

# c)
frequency <- sort(table(new_words), decreasing = TRUE)
frequency[1:5]

# d)
word_length <- numeric(length(new_words))
for (i in 1: length(new_words)){
  word_length[i] <- str_length(new_words[i])
}
names(word_length) <- new_words
word_length_count <- table(word_length)
word_length_count
plot(word_length_count)

# e)
word_length[word_length == max(word_length)]

# f)
p <- new_words[str_detect(new_words, '^p')]
p
# g)
r <- new_words[str_detect(new_words, 'r$')]
r
# h)
r[str_detect(r, '^p')]

# remove stopwords
stopfile <- "http://people.bu.edu/kalathur/datasets/stopwords.txt"
stopwords <- scan(stopfile, what=character())

new_words <- new_words[!(new_words %in% stopwords)]

# repeat c)
frequency <- sort(table(new_words), decreasing = TRUE)
frequency[1:5]

# repeat d)
word_length <- numeric(length(new_words))
for (i in 1: length(new_words)){
  word_length[i] <- str_length(new_words[i])
}
names(word_length) <- new_words
word_length_count <- table(word_length)
word_length_count
plot(word_length_count)


# Part 2) Data Wrangling
data <- 'http://people.bu.edu/kalathur/usa_daily_avg_temps.csv'
df <- read.csv(data)

# a)
usaDailyTemps <- as_tibble(df)
summary(usaDailyTemps)

# b)
year_max <- numeric(21)
for (i in seq(1995,2015)){
  yearly <- filter(usaDailyTemps, year == i)
  year_max[i-1994] <- max(yearly$avgtemp)
}
plot_ly(x = seq(1995,2015), y = year_max, type = 'bar')%>%
  layout(title = 'Max Temp each year',
         xaxis = list(title='year'),
         yaxis = list(title='temp'))

# c)
state_name <- unique(usaDailyTemps$state)
state_max <- numeric(length(state_name))
for (i in 1:length(state_name)){
  stately <- filter(usaDailyTemps, state == state_name[i])
  state_max[i] <- max(stately$avgtemp)
}
plot_ly(x = state_name, y = state_max, type = 'bar')%>%
  layout(title = 'Max Temp each state',
         xaxis = list(title='state'),
         yaxis = list(title='temp'))

# d)
bostonDailyTemps <- filter(usaDailyTemps, city == 'Boston')

# e)
# grouped by month
boston_avg_temp <- bostonDailyTemps %>%
  group_by(month) %>%
  summarise(count = n(),
            avg_temp =mean(avgtemp))

plot_ly(boston_avg_temp, x =~month, y=~avg_temp, type = 'bar')

# grouped by year and month
boston_avg_temp <- bostonDailyTemps %>%
  group_by(year,month) %>%
  summarise(count = n(),
            avg_temp =mean(avgtemp))

plot_ly(boston_avg_temp, x =~month, y=~avg_temp, type = 'scatter')

