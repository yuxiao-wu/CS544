# CS544 Homework 3
# Yuxiao Wu
# 10/21/2021

library(plotly)
library(UsingR)

options(scipen = 100, digits = 4)
# Problem 1
df <- read.csv("http://people.bu.edu/kalathur/datasets/myPrimes.csv")
# a)
# Show the barplot of the frequencies for the last digit. 
freq_last <- 0
for (i in 1:9){
  freq_last[i] <- sum(df$LastDigit == i)
}
  freq_last[10] <- sum(df$LastDigit == 0)
plot_ly(
  x = c('1','2','3','4','5','6','7','8','9','0'),
  y = freq_last,
  type = "bar"
)

# b)
# Show the barplot of the frequencies for the first digit. 
freq_first <- 0
for (i in 1:9){
  freq_first[i] <- sum(df$FirstDigit == i)
}
freq_first[10] <- sum(df$FirstDigit == 0)
plot_ly(
  x = c('1','2','3','4','5','6','7','8','9','0'),
  y = freq_first,
  name = "Freq for first digit",
  type = "bar"
)

# c)
# What inferences do you draw from these two plots? 
#   For the last digit frequency plot, we can see that all prime numbes
# Are end with number 1,2,3,5,7 or 9. And there was only one number end
# with digit '5'and '2', which is the number 5 and 2. Because all other number 
# end with digit 0,2,4,6,8 can be divided by 2 and end with 5 can be divide by 5. 
#   For the first digit frequency plot, the bar plot shows that the first
# digits for prime numbers are faily even distributed. No prime number
# started with '0', which make sense. Prime number with first digit '1'
# has the most number.

# Problem 2
us_quarters <- read.csv("http://people.bu.edu/kalathur/datasets/us_quarters.csv")
# a)
paste("DenverMint produce highest number of quarters in",us_quarters$State[which.max(us_quarters$DenverMint)])
paste("PhillyMint produce highest number of quarters in",us_quarters$State[which.max(us_quarters$PhillyMint)])
paste("DenverMint produce lowest number of quarters in",us_quarters$State[which.min(us_quarters$DenverMint)])
paste("PhillyMint produce lowest number of quarters in",us_quarters$State[which.min(us_quarters$PhillyMint)])

# b)
total_value <- (sum(us_quarters$DenverMint) + sum(us_quarters$PhillyMint))/4
total_value

# c)
quarters_table <- rbind(c(us_quarters$DenverMint), c(us_quarters$PhillyMint))
rownames(quarters_table) <- c("DenverMint", "phillyMint")
colnames(quarters_table) <- c(us_quarters$State)

barplot(quarters_table,
        beside = TRUE, legend.text = TRUE, 
        args.legend = list(x = "topright"),
        ylim = c(0,1000000),
        col=c("blue","grey"),
        las=2) 

# d)
us_quarters <- us_quarters[order(us_quarters$DenverMint), ]

us_quarters$State <- factor(us_quarters$State, levels = us_quarters$State[order(us_quarters$DenverMint)])
plot_ly(us_quarters, x = ~DenverMint, y = ~State, name = "DenverMint", type = 'scatter',
        mode = "markers", marker = list(color = "pink")) %>%
  add_trace(x = ~PhillyMint, y = ~State, name = "PhillyMint",type = 'scatter',
            mode = "markers", marker = list(color = "blue")) %>%
  layout(
    title = "Scatter Plot between two Mints",
    xaxis = list(title = "Number of Coins"),
    margin = list(l = 100)
  )

# e)
plot_ly(us_quarters, x = ~DenverMint, type="box", name = 'DM')%>%
  add_trace(us_quarters, x = ~PhillyMint, name = 'PM')%>%
  layout(
    title = "Box Plot between two Mints",
    xaxis = list(title = "Number of Coins"))

# f)
DM_q1 <- fivenum(us_quarters$DenverMint)[1]
DM_q3 <- fivenum(us_quarters$DenverMint)[3]
DM_upper_outlier <- DM_q3 + 1.5 * IQR(us_quarters$DenverMint)
DM_lower_outlier <- DM_q1 - 1.5 * IQR(us_quarters$DenverMint)
paste("Outliers States for DenverMint are",
      us_quarters$State[us_quarters$DenverMint > DM_upper_outlier],
      us_quarters$State[us_quarters$DenverMint < DM_lower_outlier]
)

PM_q1 <- fivenum(us_quarters$PhillyMint)[1]
PM_q3 <- fivenum(us_quarters$PhillyMint)[3]
PM_upper_outlier <- PM_q3 + 1.5 * IQR(us_quarters$PhillyMint)
PM_lower_outlier <- PM_q1 - 1.5 * IQR(us_quarters$PhillyMint)
paste("Outliers States for PhillyMint are",
      us_quarters$State[us_quarters$PhillyMint > PM_upper_outlier],
      us_quarters$State[us_quarters$PhillyMint < PM_lower_outlier]
)

# Problem 3
# a)
stocks <- read.csv("http://people.bu.edu/kalathur/datasets/faang.csv")
pairs(stocks[,2:6])

#b)
substocks <- stocks[,2:6]
cor(substocks)

#c)
#1.All the five stocks are positively correlated to each other, meaning that as 
# one stock price increases, another stock price would also increase.
#2.Stock Apple and stock Google has the highest correlation, which is 0.965, 
# meaning that as Apple's stock price increase by 1 dollar, Google's stock price
# increase by 0.965 dollars.
#3.Stock Netflix and stock Google has the lowest correlation, which is 0.77, 
# meaning that as Netflix's stock price increase by 1 dollar, Google's stock 
# price increase by 0.77 dollars.
#4.Since the 5 stocks are highly and positively correlated to each other, 
# therefore, I can use this inference as a sign of purchasing stock, such as, 
# when I notice a strong increase in price of one stock, there is high possibility 
# that the other 4 stock prices would also increase, which is a sign of buy in. 

# Problem 4
scores <- read.csv("http://people.bu.edu/kalathur/datasets/scores.csv")
# a)
x <- hist(scores$Score)
for (i in 1:length(x$counts)){
  print(paste(x$counts[i],"Students in range (",
              x$breaks[i],",",x$breaks[i+1],"]"))
}

#b)
x1 <- hist(scores$Score, breaks=seq(30,90,20))
paste(x1$counts[1],"Students in C grade range (",
              x1$breaks[1],",",x1$breaks[2],"]")
paste(x1$counts[2],"Students in C grade range (",
      x1$breaks[2],",",x1$breaks[3],"]")
paste(x1$counts[3],"Students in C grade range (",
      x1$breaks[3],",",x1$breaks[4],"]")
      
