# CS544 HW 2
# Name: Yuxiao Wu
# Date: 10/10/2021

library(prob)

# Part 2 Random Variables
# a)
S <- rolldie(3, makespace = TRUE)
subset(S,X1 + X2 + X3 < 10 & 6 < X1 + X2 + X3)
Prob(subset(S,X1 + X2 + X3 < 10 & 6 < X1 + X2 + X3))

# b)
subset(S, X1 == X2 & X2 == X3)
Prob(subset(S, X1 == X2 & X2 == X3))

# c)
subset(S, (X1 == X2 | X2 == X3 | X1 == X3) & !(X1==X2 & X2==X3))
Prob(subset(S, (X1 == X2 | X2 == X3 | X1 == X3) & !(X1==X2 & X2==X3)))

# d)
subset(S, X1 != X2 & X2 != X3 & X1 != X3)
Prob(subset(S, X1 != X2 & X2 != X3 & X1 != X3))

# e)
S1 <- subset(S, X1 + X2 + X3 > 9)
subset(S1, (X1 == X2 | X2 == X3 | X1 == X3) & !(X1==X2 & X2==X3))
Prob(subset(S1, (X1 == X2 | X2 == X3 | X1 == X3) & !(X1==X2 & X2==X3)))


# Part 3 Functions
# a)
sum_of_first_N_odd_squares <- function(n){
  sum <- 0
  for (i in 1:n-1)
    sum <- sum + (i*2+1)**2
  return(sum)
}

sum_of_first_N_odd_squares(2)
sum_of_first_N_odd_squares(5)
sum_of_first_N_odd_squares(10)
  
# b)
sum_of_first_N_odd_squares_V2 <- function(n){
  return(sum((1: n*2-1)**2))
}

sum_of_first_N_odd_squares_V2(2)
sum_of_first_N_odd_squares_V2(5)
sum_of_first_N_odd_squares_V2(10)



# Part 4 R 
# a)

dow <- read.csv("http://people.bu.edu/kalathur/datasets/DJI_2020.csv",
                         header=TRUE)
head(dow)

sm<-summary(dow$Close)
names(sm) = c("Min","Q1","Q2","Mean","Q3","Max")
sm
sprintf("First Quartile variation is %g", sm["Q1"] - sm["Min"])
sprintf("Second Quartile variation is %g", sm["Q2"] - sm["Q1"])
sprintf("Thrid Quartile variation is %g", sm["Q3"] - sm["Q2"])
sprintf("Forth Quartile variation is %g", sm["Max"] - sm["Q3"])

# b)
min_row <- which.min(dow$Close)
min_date <- dow$Date[which.min(dow$Close)]
paste("The minimum Dow value of", sm["Min"], "is at row", min_row,"on"
      , min_date)

# c)
dow1 <- dow$Close[min_row:length(dow$Close)]
max_close <- max(dow1)
max_close_date <- dow$Date[dow$Close==max_close]
percentage_gain <- (max_close - sm["Min"])/sm["Min"]
sprintf("I would sell on %s whe Dow is at %d for a gain of %1.2f%%",
      max_close_date, max_close ,100*percentage_gain)

# d)
DIFFS <- diff(dow$Close, lag=1)
DIFFS <- c(0, DIFFS)
dow$DIFFS <- DIFFS
head(dow)

# e)
higher_day <- sum(dow$DIFFS > 0)
lower_day <- sum(dow$DIFFS < 0)
paste(higher_day,"days Dow closed higher than previous day")
paste(lower_day,"days Dow closed lower than previous day")

# f)
subset(dow, dow$DIFFS >= 1000)

